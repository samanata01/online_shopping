﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Day20_Project2
{
    public partial class Form1 : Form
    {
        DataTable dt;
        DataTable prod;
        DataColumn dc;
        DataRow dr;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            String pid, pname, price, pdesc;
            pid = txtpid.Text;
            pname = txtpname.Text;
            price = txtprice.Text;
            pdesc = txtdesc.Text;
            try
            {
                dr = prod.NewRow();
                dr[0] = int.Parse(pid);
                dr[1] = pname;
                dr[2] = float.Parse(price);
                dr[3] = pdesc;
                prod.Rows.Add(dr);
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
            clear();
        }
        private void clear()
        {
            txtpid.Text = "";
            txtpname.Text = "";
            txtprice.Text = "";
            txtdesc.Text = "";
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            prod = Generatetable();
            dataGridView1.DataSource = prod;
        }
        DataTable Generatetable()
        {
            dt = new DataTable("Products");
            dc = new DataColumn("ProductId", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };
            dc = new DataColumn("ProductName", typeof(string));
            dt.Columns.Add(dc);
            dc = new DataColumn("ProductPrice", typeof(float));
            dt.Columns.Add(dc);
            dc = new DataColumn("ProductDescription", typeof(string));
            dt.Columns.Add(dc);
            return dt;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtprice_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtprice.Text, "[^0-9.]"))
            {
                MessageBox.Show("Do not enter non numeric  value.");
                //txtprice.Text = txtprice.Text.Remove(txtprice.Text.Length - 1);
                txtprice.Text = "";
            }
        }

        private void txtpid_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtpid.Text, "[^0-9]"))
            {
                MessageBox.Show("Do not enter non numeric  value.");
                txtpid.Text = "";
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
