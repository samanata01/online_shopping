﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Day20_Project2
{
    public partial class Cust_info : Form
    {
        DataTable dt;
        DataColumn dc;
        DataRow dr;
        DataTable Custinfo;
        public Cust_info()
        {
            InitializeComponent();
        }

        private void Cust_info_Load(object sender, EventArgs e)
        {
            Custinfo = Generatetable();
            dataGridView1.DataSource = Custinfo;
        }
        DataTable Generatetable()
        {
            dt = new DataTable("CustomerInfo");
            dc = new DataColumn("Cusid", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };
            dc = new DataColumn("Dob", typeof(string));
            dt.Columns.Add(dc);
            dc = new DataColumn("PaymentSrc", typeof(string));
            dt.Columns.Add(dc);
            dc = new DataColumn("Cashback", typeof(float));
            dt.Columns.Add(dc);
            return dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String cid,dob,ofsrc,cashback;
            cid = txtcid.Text;
            dob = cdob.Value.ToString();
            ofsrc = txtsrc.Text;
            cashback = txtcashback.Text;
            try
            {
                dr = Custinfo.NewRow();
                dr[0] = int.Parse(cid);
                dr[1] = dob;
                dr[2] = ofsrc;
                dr[3] = float.Parse(cid);
                Custinfo.Rows.Add(dr);
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
            clear();
        }
        private void clear()
        {
            txtcid.Text = "";
            cdob.Text = "";
            txtsrc.Text = "";
            txtcashback.Text = "";
        }

        private void txtcid_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtcid.Text, "[^0-9]"))
            {
                MessageBox.Show("Do not enter non numeric  value.");
                txtcid.Text = "";
            }
        }

        private void txtcashback_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtcashback.Text, "[^0-9.]"))
            {
                MessageBox.Show("Do not enter non numeric  value.");
                txtcashback.Text = "";
            }
        }
    }
}
