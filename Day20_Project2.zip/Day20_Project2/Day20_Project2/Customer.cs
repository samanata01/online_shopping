﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Day20_Project2
{
    public partial class Customer : Form
    {
        DataTable dt;
        DataColumn dc;
        DataRow dr;
        DataTable Cust;
        public Customer()
        {
            InitializeComponent();
        }
        private void txtemail_Click(object sender, EventArgs e)
        {

        }
        private void Customer_Load(object sender, EventArgs e)
        {
            Cust = Generatetable();
            dataGridView1.DataSource = Cust;
        }
        DataTable Generatetable()
        {
            dt = new DataTable("Customer");
            dc = new DataColumn("CustID", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };
            dc = new DataColumn("CustName", typeof(string));
            dt.Columns.Add(dc);
            dc = new DataColumn("ContactNum", typeof(Int64));
            dt.Columns.Add(dc);
            dc = new DataColumn("Email", typeof(string));
            dt.Columns.Add(dc);
            dc = new DataColumn("Address", typeof(string));
            dt.Columns.Add(dc);
            return dt;
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            String cusid, cname, cnum,email,addr;
            cusid = txtcid.Text;
            cname = txtcname.Text;
            cnum = txtcnum.Text;
            email = txtemail.Text;
            addr = txtaddr.Text;
            try
            {
                dr = Cust.NewRow();
                dr[0] = int.Parse(cusid);
                dr[1] = cname;
                dr[2] = long.Parse(cnum);
                dr[3] = email;
                dr[4] = addr;
                Cust.Rows.Add(dr);
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
            clear();
        }
        private void clear()
        {
            txtcid.Text = "";
            txtcname.Text = "";
            txtcnum.Text = "";
            txtemail.Text = "";
            txtaddr.Text = "";
        }

        
        private void cusid_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtcid.Text, "[^0-9]"))
            {
                MessageBox.Show("Do not enter non numeric  value.");
                txtcid.Text = "";
            }
        }

        private void cusnum_TextChanged(object sender, EventArgs e)
        {
            txtcnum.MaxLength = 10;
            
            if (Regex.IsMatch(txtcnum.Text, "[^0-9]"))
            {
                MessageBox.Show("Do not enter non numeric  value.");
                txtcnum.Text = "";
            }
            
        }

        private void txtemail_TextChanged(object sender, EventArgs e)
        {
            if (txtcnum.Text.Length < 10)
            {
                MessageBox.Show("Enter valid 10 digit Contact number");
            }
        }
    }
}
