﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Day20_Project2
{
    public partial class Orders : Form
    {
        DataTable dt;
        DataColumn dc;
        DataRow dr;
        DataTable Ord;
        public Orders()
        {
            InitializeComponent();
        }

        private void Orders_Load(object sender, EventArgs e)
        {
            Ord = Generatetable();
            dataGridView1.DataSource = Ord;
        }
        DataTable Generatetable()
        {
            dt = new DataTable("Orders");
            dc = new DataColumn("OrderId", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };
            dc = new DataColumn("ProdId", typeof(string));
            dt.Columns.Add(dc);
            dc = new DataColumn("Quantity", typeof(float));
            dt.Columns.Add(dc);
            return dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String oid, pid, quan;
            oid = txtoid.Text;
            pid = txtpid.Text;
            quan = txtquan.Text;
            try
            {
                dr = Ord.NewRow();
                dr[0] = int.Parse(oid);
                dr[1] = int.Parse(pid);
                dr[2] = float.Parse(quan);
                Ord.Rows.Add(dr);
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
            clear();
        }
        private void clear()
        {
            txtoid.Text = "";
            txtpid.Text = "";
            txtquan.Text = "";
        }

        private void txtoid_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtoid.Text, "[^0-9]"))
            {
                MessageBox.Show("Do not enter non numeric  value.");
                txtoid.Text = "";
            }
        }

        private void txtpid_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtpid.Text, "[^0-9]"))
            {
                MessageBox.Show("Do not enter non numeric  value.");
                txtpid.Text = "";
            }
        }

        private void txtquan_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtquan.Text, "[^0-9.]"))
            {
                MessageBox.Show("Do not enter non numeric  value.");
                txtquan.Text = "";
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
