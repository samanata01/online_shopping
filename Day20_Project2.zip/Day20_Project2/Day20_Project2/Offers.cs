﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Day20_Project2
{
    public partial class Offers : Form
    {
        DataTable dt;
        DataColumn dc;
        DataRow dr;
        DataTable offer;
        public Offers()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void txtprosrc_TextChanged(object sender, EventArgs e)
        {
        }

        private void txt0ffdisc_TextChanged(object sender, EventArgs e)
        {
        }
        private void Offers_Load(object sender, EventArgs e)
        {
            offer = Generatetable();
            dataGridView1.DataSource = offer;
        }

        DataTable Generatetable()
        {
            dt = new DataTable("Offers");
            dc = new DataColumn("OfferId", typeof(int));
            dt.Columns.Add(dc);
            dt.PrimaryKey = new DataColumn[] { dc };
            dc = new DataColumn("OfferDiscount", typeof(float));
            dt.Columns.Add(dc);
            dc = new DataColumn("PromoSource", typeof(string));
            dt.Columns.Add(dc);
            return dt;
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            String offid, disc, promosrc;
            offid = txtoffid.Text;
            disc = txtoffdisc.Text;
            promosrc = txtprosrc.Text;
            try
            {
                dr = offer.NewRow();
                dr[0] = int.Parse(offid);
                dr[1] = float.Parse(disc);
                dr[2] = promosrc;
                offer.Rows.Add(dr);
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
            clear();
        }
        private void clear()
        {
            txtoffid.Text = "";
            txtoffdisc.Text = "";
            txtprosrc.Text = "";
        }
        private void txtoffdisc_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtoffdisc.Text, "[^0-9.]"))
            {
                MessageBox.Show("Do not enter non numeric  value.");
                txtoffdisc.Text = "";
            }
        }

        private void txtoffid_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(txtoffid.Text, "[^0-9]"))
            {
                MessageBox.Show("Do not enter non numeric  value.");
                txtoffid.Text = "";
            }
        }
    }
}
