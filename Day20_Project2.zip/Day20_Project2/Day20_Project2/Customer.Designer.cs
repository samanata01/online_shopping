﻿namespace Day20_Project2
{
    partial class Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cid = new System.Windows.Forms.Label();
            this.cname = new System.Windows.Forms.Label();
            this.cnum = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.Label();
            this.addr = new System.Windows.Forms.Label();
            this.txtcid = new System.Windows.Forms.TextBox();
            this.txtcname = new System.Windows.Forms.TextBox();
            this.txtcnum = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtaddr = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnsubmit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // cid
            // 
            this.cid.AutoSize = true;
            this.cid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cid.ForeColor = System.Drawing.Color.MediumTurquoise;
            this.cid.Location = new System.Drawing.Point(82, 39);
            this.cid.Name = "cid";
            this.cid.Size = new System.Drawing.Size(129, 25);
            this.cid.TabIndex = 0;
            this.cid.Text = "Customer Id";
            // 
            // cname
            // 
            this.cname.AutoSize = true;
            this.cname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cname.ForeColor = System.Drawing.Color.MediumTurquoise;
            this.cname.Location = new System.Drawing.Point(82, 106);
            this.cname.Name = "cname";
            this.cname.Size = new System.Drawing.Size(167, 25);
            this.cname.TabIndex = 1;
            this.cname.Text = "Customer Name";
            // 
            // cnum
            // 
            this.cnum.AutoSize = true;
            this.cnum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cnum.ForeColor = System.Drawing.Color.MediumTurquoise;
            this.cnum.Location = new System.Drawing.Point(82, 174);
            this.cnum.Name = "cnum";
            this.cnum.Size = new System.Drawing.Size(168, 25);
            this.cnum.TabIndex = 2;
            this.cnum.Text = "Contact Number";
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.ForeColor = System.Drawing.Color.MediumTurquoise;
            this.email.Location = new System.Drawing.Point(82, 242);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(65, 25);
            this.email.TabIndex = 3;
            this.email.Text = "Email";
            this.email.Click += new System.EventHandler(this.txtemail_Click);
            // 
            // addr
            // 
            this.addr.AutoSize = true;
            this.addr.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addr.ForeColor = System.Drawing.Color.MediumTurquoise;
            this.addr.Location = new System.Drawing.Point(82, 309);
            this.addr.Name = "addr";
            this.addr.Size = new System.Drawing.Size(92, 25);
            this.addr.TabIndex = 4;
            this.addr.Text = "Address";
            // 
            // txtcid
            // 
            this.txtcid.Location = new System.Drawing.Point(297, 38);
            this.txtcid.Name = "txtcid";
            this.txtcid.Size = new System.Drawing.Size(100, 26);
            this.txtcid.TabIndex = 5;
            this.txtcid.Click += new System.EventHandler(this.cusid_TextChanged);
            this.txtcid.TextChanged += new System.EventHandler(this.cusid_TextChanged);
            // 
            // txtcname
            // 
            this.txtcname.Location = new System.Drawing.Point(297, 105);
            this.txtcname.Name = "txtcname";
            this.txtcname.Size = new System.Drawing.Size(100, 26);
            this.txtcname.TabIndex = 6;
            // 
            // txtcnum
            // 
            this.txtcnum.Location = new System.Drawing.Point(297, 173);
            this.txtcnum.Name = "txtcnum";
            this.txtcnum.Size = new System.Drawing.Size(100, 26);
            this.txtcnum.TabIndex = 7;
            this.txtcnum.Click += new System.EventHandler(this.cusnum_TextChanged);
            this.txtcnum.TextChanged += new System.EventHandler(this.cusnum_TextChanged);
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(297, 241);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(100, 26);
            this.txtemail.TabIndex = 8;
            this.txtemail.TextChanged += new System.EventHandler(this.txtemail_TextChanged);
            // 
            // txtaddr
            // 
            this.txtaddr.Location = new System.Drawing.Point(297, 308);
            this.txtaddr.Name = "txtaddr";
            this.txtaddr.Size = new System.Drawing.Size(100, 26);
            this.txtaddr.TabIndex = 9;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(493, 38);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(908, 353);
            this.dataGridView1.TabIndex = 10;
            // 
            // btnsubmit
            // 
            this.btnsubmit.BackColor = System.Drawing.Color.SeaShell;
            this.btnsubmit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnsubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsubmit.ForeColor = System.Drawing.Color.DimGray;
            this.btnsubmit.Location = new System.Drawing.Point(297, 376);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(100, 42);
            this.btnsubmit.TabIndex = 11;
            this.btnsubmit.Text = "Submit";
            this.btnsubmit.UseVisualStyleBackColor = false;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1459, 450);
            this.Controls.Add(this.btnsubmit);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtaddr);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.txtcnum);
            this.Controls.Add(this.txtcname);
            this.Controls.Add(this.txtcid);
            this.Controls.Add(this.addr);
            this.Controls.Add(this.email);
            this.Controls.Add(this.cnum);
            this.Controls.Add(this.cname);
            this.Controls.Add(this.cid);
            this.Name = "Customer";
            this.Text = "Customer";
            this.Load += new System.EventHandler(this.Customer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label cid;
        private System.Windows.Forms.Label cname;
        private System.Windows.Forms.Label cnum;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Label addr;
        private System.Windows.Forms.TextBox txtcid;
        private System.Windows.Forms.TextBox txtcname;
        private System.Windows.Forms.TextBox txtcnum;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txtaddr;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnsubmit;
    }
}